package org.techtown.mission25;

import android.view.View;

public interface OnPictureItemClickListener {
    public void onItemClick(PictureAdapter.ViewHolder holder, View view, int position);
}
