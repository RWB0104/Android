package org.techtown.push;

import android.view.View;

public interface OnFriendItemClickListener {
    public void onItemClick(FriendAdapter.ViewHolder holder, View view, int position);
}
